
    <footer>
        <hr>
        This is the footer.
    </footer>

</div>
</body>
</html>
