<?php
    $title = "Home Page";
    require '../view/headerInclude.php';
?>
    <section id="main">
        <h1>This is content.</h1>
    </section>

<?php
    require '../view/footerInclude.php';
?>

