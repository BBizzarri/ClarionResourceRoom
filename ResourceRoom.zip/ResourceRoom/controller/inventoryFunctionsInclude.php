<?php

    // This file is included in the main controller as a series of functions.  All code should be within function scope.
    // The purpose is to separate the shopper actions from the back-end inventory actions to help version control.  These
    // functions should all be called from code in the inventoryCasesInclude.php file

?>